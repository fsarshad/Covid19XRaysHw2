def preprocessor(img_path):
    img = Image.open(img_path).convert("RGB").resize(image_size) # import image, make sure it's RGB and resize to height and width you want.
    img = (np.float32(img)-1.)/(255-1.) # min max transformation
    img=img.reshape(image_size + (3,)) # Create final shape as array with correct dimensions for Keras
    return img
